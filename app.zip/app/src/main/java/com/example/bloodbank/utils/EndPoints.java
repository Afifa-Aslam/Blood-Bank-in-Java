package com.example.bloodbank.utils;

public class EndPoints {
    private static final String base_url = "http://piscesweb.000webhostapp.com/";
    public static final String register_url = base_url+ "register.php";
}
